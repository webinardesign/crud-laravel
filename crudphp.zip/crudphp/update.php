<?php
include 'config.php';

$id = 1;
$newName = "Jane Doe";
$newEmail = "jane@example.com";

$sql = "UPDATE users SET name='$newName', email='$newEmail' WHERE id=$id";
if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>
