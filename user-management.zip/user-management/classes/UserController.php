<?php
class UserController {
    private $userRepo;

    public function __construct(UserRepository $userRepo) {
        $this->userRepo = $userRepo;
    }

    public function addUser() {
        $errors = [];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';

            try {
                $user = new User();
                $user->setName($name);
                $user->setEmail($email);
                if ($this->userRepo->emailExists($email)) {
                    throw new Exception("Email already exists");
                }
                $user->setPassword($password);
                $this->userRepo->addUser($user);
                header('Location: index.php?action=list');
                exit;
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
            }
        }
        include 'views/add_user_form.php';
    }


    public function listUsers() {
        $users = $this->userRepo->getAllUsers();
        include 'views/user_list.php';
    }


    public function viewUser() {
        $id = $_GET['id'] ?? null;
        $user = $this->userRepo->findById($id);
        if (!$user) {
            die("User not found");
        }
        include 'views/view_user.php';
    }

  
    public function updateUser() {
        $id = $_GET['id'] ?? null;
        $user = $this->userRepo->findById($id);
        if (!$user) {
            die("User not found");
        }

        $errors = [];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';

            try {
                $user->setName($name);
                if ($email !== $user->getEmail() && $this->userRepo->emailExists($email, $id)) {
                    throw new Exception("Email already exists");
                }
                $user->setEmail($email);
                if (!empty($password)) {
                    $user->setPassword($password);
                }
                $this->userRepo->updateUser($user);
                header('Location: index.php?action=list');
                exit;
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
            }
        }
        include 'views/update_user_form.php';
    }


    public function deleteUser() {
        $id = $_GET['id'] ?? null;
        if ($this->userRepo->findById($id)) {
            $this->userRepo->deleteUser($id);
        }
        header('Location: index.php?action=list');
        exit;
    }


    public function searchUsers() {
        $query = $_GET['query'] ?? '';
        $users = $this->userRepo->searchUsers($query);
        include 'views/user_list.php';
    }


    public function login() {
        $errors = [];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $user = $this->userRepo->findByEmail($email);
            if ($user && password_verify($password, $user->getPassword())) {
                $_SESSION['logged_in'] = true;
                header('Location: index.php?action=list');
                exit;
            } else {
                $errors[] = "Invalid email or password";
            }
        }
        include 'views/login_form.php';
    }

  
    public function logout() {
        session_destroy();
        header('Location: index.php?action=login');
        exit;
    }
}
?>