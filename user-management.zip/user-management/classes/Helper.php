<?php
class Helper {

    public static function formatDate($date) {
        return date('F j, Y, g:i a', strtotime($date));
    }


    public static function sanitize($input) {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
}
?>