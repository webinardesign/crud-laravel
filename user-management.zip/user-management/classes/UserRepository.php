<?php
class UserRepository {
    private $filePath;

    public function __construct($filePath) {
        $this->filePath = $filePath;
        if (!file_exists($this->filePath)) {
            file_put_contents($this->filePath, json_encode([]));
        }
    }

    public function getAllUsers() {
        $data = file_get_contents($this->filePath);
        return json_decode($data, true) ?: [];
    }


    public function findById($id) {
        $users = $this->getAllUsers();
        foreach ($users as $userData) {
            if ($userData['id'] == $id) {
                return new User(
                    $userData['id'],
                    $userData['name'],
                    $userData['email'],
                    $userData['password'],
                    $userData['created_at']
                );
            }
        }
        return null;
    }
    public function findByEmail($email) {
        $users = $this->getAllUsers();
        foreach ($users as $userData) {
            if ($userData['email'] === $email) {
                return new User(
                    $userData['id'],
                    $userData['name'],
                    $userData['email'],
                    $userData['password'],
                    $userData['created_at']
                );
            }
        }
        return null;
    }
    public function emailExists($email, $excludeId = null) {
        $users = $this->getAllUsers();
        foreach ($users as $user) {
            if ($user['email'] === $email && ($excludeId === null || $user['id'] != $excludeId)) {
                return true;
            }
        }
        return false;
    }
    public function addUser(User $user) {
        $users = $this->getAllUsers();
        $userData = $user->toArray();
        $userData['id'] = $this->getNextId();
        $users[] = $userData;
        $this->saveUsers($users);
        return $userData['id'];
    }
    public function updateUser(User $user) {
        $users = $this->getAllUsers();
        foreach ($users as &$userData) {
            if ($userData['id'] == $user->getId()) {
                $userData = $user->toArray();
                break;
            }
        }
        $this->saveUsers($users);
    }
    public function deleteUser($id) {
        $users = $this->getAllUsers();
        $users = array_filter($users, function ($user) use ($id) {
            return $user['id'] != $id;
        });
        $this->saveUsers(array_values($users));
    }
    public function searchUsers($query) {
        $users = $this->getAllUsers();
        $query = strtolower(trim($query));
        return array_filter($users, function ($user) use ($query) {
            return stripos($user['name'], $query) !== false || stripos($user['email'], $query) !== false;
        });
    }
    private function getNextId() {
        $users = $this->getAllUsers();
        $ids = array_column($users, 'id');
        return empty($ids) ? 1 : max($ids) + 1;
    }
    private function saveUsers($users) {
        file_put_contents($this->filePath, json_encode($users, JSON_PRETTY_PRINT));
    }
}
?>