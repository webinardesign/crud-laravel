<?php
class User {
    private $id;
    private $name;
    private $email;
    private $password;
    private $created_at;

    public function __construct($id = null, $name = '', $email = '', $password = '', $created_at = null) {
        $this->id = $id;
        $this->name = $name;
        $this->email = $email;
        $this->password = $password;
        $this->created_at = $created_at ?? date('Y-m-d H:i:s');
    }


    public function getId() {
        return $this->id;
    }

    public function getName() {
        return $this->name;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getCreatedAt() {
        return $this->created_at;
    }


    public function setName($name) {
        $name = htmlspecialchars(trim($name), ENT_QUOTES, 'UTF-8');
        if (empty($name)) {
            throw new Exception("Name cannot be empty");
        }
        $this->name = $name;
    }

    public function setEmail($email) {
        $email = trim($email);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }
        $this->email = $email;
    }

    public function setPassword($password) {
        if (strlen($password) < 6) {
            throw new Exception("Password must be at least 6 characters long");
        }
        $this->password = password_hash($password, PASSWORD_BCRYPT);
    }


    public function toArray() {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'password' => $this->password,
            'created_at' => $this->created_at
        ];
    }
}
?>