<?php
session_start();


require_once 'classes/User.php';
require_once 'classes/UserRepository.php';
require_once 'classes/UserController.php';
require_once 'classes/Helper.php';


$userRepo = new UserRepository('data/users.json');
$userController = new UserController($userRepo);

$action = isset($_GET['action']) ? $_GET['action'] : 'list';

$protectedActions = ['add', 'update', 'delete', 'view', 'list', 'search'];
if (in_array($action, $protectedActions) && !isset($_SESSION['logged_in'])) {
    $action = 'login';
}

switch ($action) {
    case 'add':
        $userController->addUser();
        break;
    case 'list':
        $userController->listUsers();
        break;
    case 'view':
        $userController->viewUser();
        break;
    case 'update':
        $userController->updateUser();
        break;
    case 'delete':
        $userController->deleteUser();
        break;
    case 'search':
        $userController->searchUsers();
        break;
    case 'login':
        $userController->login();
        break;
    case 'logout':
        $userController->logout();
        break;
    default:
        $userController->listUsers();
}
?>