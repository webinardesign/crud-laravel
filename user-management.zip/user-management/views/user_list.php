<?php include 'header.php'; ?>
<h2>User List</h2>
<form method="GET" action="index.php">
    <input type="hidden" name="action" value="search">
    <input type="text" name="query" placeholder="Search by name or email" value="<?php echo Helper::sanitize($query ?? ''); ?>">
    <button type="submit">Search</button>
</form>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Created At</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo Helper::sanitize($user['id']); ?></td>
            <td><?php echo Helper::sanitize($user['name']); ?></td>
            <td><?php echo Helper::sanitize($user['email']); ?></td>
            <td><?php echo Helper::formatDate($user['created_at']); ?></td>
            <td>
                <a href="index.php?action=view&id=<?php echo $user['id']; ?>">View</a> |
                <a href="index.php?action=update&id=<?php echo $user['id']; ?>">Edit</a> |
                <a href="index.php?action=delete&id=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<br>
<a style="  background-color: #153d0cff;color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-size: 1em;" href="index.php?action=add">Add New User</a> | <a style="  background-color: #9a1010ff;color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-size: 1em;" href="index.php?action=logout">Logout</a>
</body>
</html>