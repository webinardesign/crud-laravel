<?php include 'header.php'; ?>
<h2>Login</h2>
<?php if (!empty($errors)){ ?>
    <ul class="error">
        <?php foreach ($errors as $error){ ?>
            <li><?php echo Helper::sanitize($error); ?></li>
        <?php } ?>
    </ul>
<?php } ?>
<form method="POST" action="index.php?action=login">
    <label>Email:</label>
    <input type="email" name="email" required><br>
    <label>Password:</label>
    <input type="password" name="password" required><br>
    <button type="submit">Login</button>
</form>
</body>
</html>