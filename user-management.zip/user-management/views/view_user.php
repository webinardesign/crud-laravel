<?php include 'header.php'; ?>
<h2>User Details</h2>
<p><strong>ID:</strong> <?php echo Helper::sanitize($user->getId()); ?></p>
<p><strong>Name:</strong> <?php echo Helper::sanitize($user->getName()); ?></p>
<p><strong>Email:</strong> <?php echo Helper::sanitize($user->getEmail()); ?></p>
<p><strong>Created At:</strong> <?php echo Helper::formatDate($user->getCreatedAt()); ?></p>
<a href="index.php?action=list">Back to List</a>
</body>
</html>