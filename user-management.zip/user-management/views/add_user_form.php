<?php include 'header.php'; ?>
<h2>Add New User</h2>
<?php if (!empty($errors)){ ?>
    <ul class="error">
        <?php foreach ($errors as $error){ ?>
            <li><?php echo Helper::sanitize($error); ?></li>
        <?php } ?>
    </ul>
<?php } ?>
<form method="POST" action="index.php?action=add">
    <label>Name:</label>
    <input type="text" name="name" required><br>
    <label>Email:</label>
    <input type="email" name="email" required><br>
    <label>Password:</label>
    <input type="password" name="password" required><br>
    <button type="submit">Add User</button>
</form>
<a href="index.php?action=list">Back to List</a>
</body>
</html>