<?php include 'header.php'; ?>
<h2>Update User</h2>
<?php if (!empty($errors)){ ?>
    <ul class="error">
        <?php foreach ($errors as $error){ ?>
            <li><?php echo Helper::sanitize($error); ?></li>
        <?php } ?>
    </ul>
<?php } ?>
<form method="POST" action="index.php?action=update&id=<?php echo $user->getId(); ?>">
    <label>Name:</label>
    <input type="text" name="name" value="<?php echo Helper::sanitize($user->getName()); ?>" required><br>
    <label>Email:</label>
    <input type="email" name="email" value="<?php echo Helper::sanitize($user->getEmail()); ?>" required><br>
    <label>Password:</label>
    <input type="password" name="password"><br>
    <button type="submit">Update User</button>
</form>
<a href="index.php?action=list">Back to List</a>
</body>
</html>