<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Simple Laravel 11 CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <div class="bg-dark py-3">
        <h3 class="text-white text-center">Simple Laravel 11 CRUD</h3>
    </div>
    <div class="container">
    @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
        <div class="row d-flex justify-content-center">
                
            <div class="col-md-10">
                <div class="card borde-0 shadow-lg my-4">
                    <div class="card-header bg-dark">
                        <h3 class="text-white">Products</h3>
                    </div>
             <!-- <pre>{{ print_r($cart, true) }}</pre>  -->
        <h3>Your Cart</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Product ID</th>
                    
                    <th>Price</th>
                    <th>Product Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($cart as $item)
        <tr>
            <td>{{ $item->prod_id }}</td>
            <td>{{ $item->price }}</td>
            <td>{{ $item->product->name ?? 'Product Not Found' }}</td>
            <td>
                <a href="{{ route('cart.remove', $item->id) }}" class="btn btn-danger btn-sm">Remove</a>
                <a href="{{ route('products.checkout',$item->id) }}" class="btn btn-info btn-sm">checkout</a>
            </td>
        </tr>
    @endforeach
            </tbody>
        </table>
    </div>
                   
                </div>
            </div>
        </div>
    </div>
    
  </body>
</html>
