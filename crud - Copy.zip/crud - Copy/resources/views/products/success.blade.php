<!DOCTYPE html>
<html>
<head>
    <title>Order Successful</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5 text-center">
    <h2 class="text-success">Thank You! 🎉</h2>
    <p>Your order has been placed successfully.</p>
    <p><strong>Order Invoice No:</strong> {{ session('invoice_no') }}</p>
    <a href="{{ route('products.index') }}" class="btn btn-primary">Continue Shopping</a>
</div>
</body>
</html>
