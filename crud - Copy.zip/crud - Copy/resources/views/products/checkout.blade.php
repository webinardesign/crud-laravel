<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Checkout for: {{ $cartItem->product->name ?? 'Product' }}</h2> <a href="{{ route('products.cart') }}" class="btn btn-secondary">Back to Cart</a>

    <form action="{{ route('billing.store') }}" method="POST">
    @csrf
    <input type="hidden" name="cart_id" value="{{ $cartItem->id }}">
    <input type="hidden" name="amount" value="{{ $cartItem->product->price }}">

    <div class="mb-3">
        <label>Full Name</label>
        <input type="text" name="full_name" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Email Address</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Phone Number</label>
        <input type="text" name="phone" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Shipping Address</label>
        <textarea name="address" class="form-control" required></textarea>
    </div>

    <h3>Amount: ${{ $cartItem->product->price ?? '0.00' }}</h3>
    <br>

    <div class="mb-3">
        <label>Select Payment Method:</label> <br>
        <input type="radio" name="payment_mode" value="online" required> Online <br>
        <input type="radio" name="payment_mode" value="offline" required> Offline <br>
    </div>

    <button type="submit" class="btn btn-success">Pay</button>
</form>

</div>
</body>
</html>
