<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Simple Laravel 11 CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <div class="bg-dark py-3">
        <h3 class="text-white text-center">Simple Laravel 11 CRUD</h3>
    </div>
    <div class="container">
    <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <div class="row d-flex justify-content-center">
                
            <div class="col-md-10">
                <div class="card borde-0 shadow-lg my-4">
                    <div class="card-header bg-dark">
                        <h3 class="text-white">Products</h3>
                    </div>
             <!-- <pre><?php echo e(print_r($cart, true)); ?></pre>  -->
        <h3>Your Cart</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Product ID</th>
                    
                    <th>Price</th>
                    <th>Product Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->prod_id); ?></td>
            <td><?php echo e($item->price); ?></td>
            <td><?php echo e($item->product->name ?? 'Product Not Found'); ?></td>
            <td>
                <a href="<?php echo e(route('cart.remove', $item->id)); ?>" class="btn btn-danger btn-sm">Remove</a>
                <a href="<?php echo e(route('products.checkout',$item->id)); ?>" class="btn btn-info btn-sm">checkout</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
                   
                </div>
            </div>
        </div>
    </div>
    
  </body>
</html>
<?php /**PATH C:\xampp2\htdocs\crudlaravel\crud\resources\views/products/cart.blade.php ENDPATH**/ ?>