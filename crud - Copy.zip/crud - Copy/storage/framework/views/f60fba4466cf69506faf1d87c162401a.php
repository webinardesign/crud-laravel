<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Checkout for: <?php echo e($cartItem->product->name ?? 'Product'); ?></h2> <a href="<?php echo e(route('products.cart')); ?>" class="btn btn-secondary">Back to Cart</a>

    <form action="<?php echo e(route('billing.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="cart_id" value="<?php echo e($cartItem->id); ?>">
    <input type="hidden" name="amount" value="<?php echo e($cartItem->product->price); ?>">

    <div class="mb-3">
        <label>Full Name</label>
        <input type="text" name="full_name" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Email Address</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Phone Number</label>
        <input type="text" name="phone" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Shipping Address</label>
        <textarea name="address" class="form-control" required></textarea>
    </div>

    <h3>Amount: $<?php echo e($cartItem->product->price ?? '0.00'); ?></h3>
    <br>

    <div class="mb-3">
        <label>Select Payment Method:</label> <br>
        <input type="radio" name="payment_mode" value="online" required> Online <br>
        <input type="radio" name="payment_mode" value="offline" required> Offline <br>
    </div>

    <button type="submit" class="btn btn-success">Pay</button>
</form>

</div>
</body>
</html>
<?php /**PATH C:\xampp2\htdocs\crudlaravel\crud\resources\views/products/checkout.blade.php ENDPATH**/ ?>