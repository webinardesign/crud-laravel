<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;

    // Specify the table name if different from the plural form of the model
    protected $table = 'carts';

    // The attributes that are mass assignable
    protected $fillable = [
        'prod_id',
        'price',
        'created_at',
        'updated_at',
    ];
    public function product()
    {
        return $this->belongsTo(Product::class, 'prod_id');
    }
    
}
