<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'cart_id',
        'billing_id',
        'prod_id',
        'invoice_no',
        'amount',
        'placed_date',
        'payment_status',
        'payment_mode'
    ];

    public function cart()
    {
        return $this->belongsTo(Cart::class);
    }

    public function billing()
    {
        return $this->belongsTo(Billing::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'prod_id');
    }
}
